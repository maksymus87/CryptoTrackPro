"""
Telegram bot for cryptocurrency trading signals.
"""
